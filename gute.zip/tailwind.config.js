module.exports = {
  content: ["./**/*.php", "./src/**/*.js", "./src/**/*.jsx", "./src/**/*.ts", "./src/**/*.tsx"],
}
